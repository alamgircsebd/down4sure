<?php

namespace Routiz\Inc\Src\Listing\Modules\Meta;

use \Routiz\Inc\Src\Listing\Modules\Module;

class Meta extends Module {

    // ..

}
