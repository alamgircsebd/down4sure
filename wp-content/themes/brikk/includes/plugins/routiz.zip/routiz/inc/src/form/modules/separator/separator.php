<?php

namespace Routiz\Inc\Src\Form\Modules\Separator;

use \Routiz\Inc\Src\Form\Modules\Module;

class Separator extends Module {

    // ..

}
