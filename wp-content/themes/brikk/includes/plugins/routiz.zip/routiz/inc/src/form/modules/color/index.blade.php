@include('label.index')

<input type="text" name="{{ $id }}" value="{{ $value }}" class="rz-colorpicker">
