<?php

namespace Routiz\Inc\Src\Explore\Search;

use \Routiz\Inc\Src\Traits\Singleton;
use \Routiz\Inc\Src\Explore\Explore as Main_Explore;

class Explore extends Main_Explore {

    use Singleton;

}
