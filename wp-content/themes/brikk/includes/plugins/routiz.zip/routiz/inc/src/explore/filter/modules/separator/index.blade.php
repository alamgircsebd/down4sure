<div class="rz-form-group rz-col-12">
    <span class="rz-filter-separator"></span>
</div>
