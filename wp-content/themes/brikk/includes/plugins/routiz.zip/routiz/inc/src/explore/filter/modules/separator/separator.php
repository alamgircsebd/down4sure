<?php

namespace Routiz\Inc\Src\Explore\Filter\Modules\Separator;

use \Routiz\Inc\Src\Explore\Filter\Modules\Module;
use \Routiz\Inc\Src\Explore\Filter\Comparison;

class Separator extends Module {

    public function controller() {

        return [];

        // return array_merge( (array) $this->props, [
        //     'component' => $this->component,
        // ]);

    }

    public function query() {
        return [];
    }

}
