<div class="rz-step-publish rz-text-center">
    <div>
        <span class="rz--icon"><i class="fas fa-paper-plane"></i></span>
        <h4 class="rz--title">{{ $strings->about_publish }}</h4>
        <p>{{ $strings->confirm }}</p>
    </div>
</div>
