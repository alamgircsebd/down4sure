<?php

namespace Routiz\Inc\Src\Form\Modules\Heading;

use \Routiz\Inc\Src\Form\Modules\Module;

class Heading extends Module {

    // ..

}
