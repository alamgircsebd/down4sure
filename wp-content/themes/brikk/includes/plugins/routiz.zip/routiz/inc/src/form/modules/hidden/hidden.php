<?php

namespace Routiz\Inc\Src\Form\Modules\Hidden;

use \Routiz\Inc\Src\Form\Modules\Module;

class Hidden extends Module {

    // ..

}
